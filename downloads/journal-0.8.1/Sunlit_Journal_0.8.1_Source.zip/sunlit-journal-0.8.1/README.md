# Sunlit Journal

Forge 1.20.1용 수첩 전용 0.8.1-journal 개발 버전입니다.
프로필 / 생활 기술 / 업무 일지 / 업적 도감 / 칭호 도감의 다섯 탭을 제공합니다.

현재 버전의 기능·보상·구버전 데이터 호환·빌드는 [README_JOURNAL_ONLY.md](README_JOURNAL_ONLY.md), 검증 결과와 한계는 [JOURNAL_VALIDATION.md](JOURNAL_VALIDATION.md)를 참고하세요.

main 0.7.0의 스킨 공방·뽑기·뽑기권 보너스는 이 버전에서 제공하지 않습니다. 기존 아이템·차원 ID와 원본 소유 NBT는 세이브 호환을 위해 유지합니다.

0.8.1에서는 승인 시안을 참고한 생활 분야 삽화 8종과 계절 공동 축제 삽화 4종을 실제 카드에 반영했습니다. [그림·계절 이벤트 변경 및 화면 구분](ILLUSTRATIONS_0.8.1.md)을 참고하세요.
