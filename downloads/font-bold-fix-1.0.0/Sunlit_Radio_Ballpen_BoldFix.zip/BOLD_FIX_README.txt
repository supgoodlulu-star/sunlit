볼드 겹침 보정용 리소스팩 (Minecraft 1.20.1)

이 ZIP은 resourcepacks 폴더, sunlit-font-bold-fix-1.0.0.jar는 클라이언트 mods 폴더에 넣으세요. 서버에는 보정 모드를 설치할 필요가 없습니다.
일반 글꼴 PNG, 크기, 기본 자간은 원본 그대로입니다. 마지막 글자 표의 잘못된 빈칸 코드만 정리했습니다.
볼드 덧그림 1픽셀을 0.25픽셀로 줄이는 효과는 보정 모드가 담당하며 리소스팩만으로는 적용되지 않습니다.
config/sunlit_font_bold_fix-client.toml의 boldOffset을 0.0으로 설정하면 이 글꼴의 볼드 덧그림을 없앨 수 있습니다.
