Sunlit Valley Radio Ballpen Font - Minecraft 1.20.1

1. Copy this ZIP to .minecraft/resourcepacks (or the Modrinth profile resourcepacks folder).
2. Enable it under Options > Resource Packs. Place it above other font packs.
3. Friends must enable the same pack to see the same font.

Font source: user-provided 온글잎 레디오 볼펜체.ttf
Some unsupported glyphs use vanilla fallback. Font redistribution license was not verified; share only where permitted.
